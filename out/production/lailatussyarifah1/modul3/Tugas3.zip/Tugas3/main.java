package modul3.Tugas3;

public class main {
    public static void main(String[] args) {
        User user = new User();
        user.login();
        user.dashboard();
        user.updatePassword();
        user.updateStatus();
    }
}
