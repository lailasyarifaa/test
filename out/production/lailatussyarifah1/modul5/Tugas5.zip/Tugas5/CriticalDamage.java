package modul5.Tugas5;

public interface CriticalDamage {
    double bonusDamage = 0.4;
}
