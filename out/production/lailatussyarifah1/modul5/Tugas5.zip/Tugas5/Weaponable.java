package modul5.Tugas5;

public interface Weaponable {
    public void useWeaponable();
}
