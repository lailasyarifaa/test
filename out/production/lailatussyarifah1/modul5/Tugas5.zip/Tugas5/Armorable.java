package modul5.Tugas5;

public interface Armorable {
    public void userArmor();
}
