package modul5.Tugas5;

public interface MagicalDamage {
    double magicalDamagebonus = 0.8;
}
