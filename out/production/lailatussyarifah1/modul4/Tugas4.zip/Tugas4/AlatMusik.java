package modul4.Tugas4;

public interface AlatMusik {
    float MAX_DISCOUNT = 0.15f;

    float getDiscountPrice(float price, float discount);

    void tampilkanAlatMusik();
}
