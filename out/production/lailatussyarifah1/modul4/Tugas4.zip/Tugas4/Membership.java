package modul4.Tugas4;

public interface Membership {
    double PREMIUM_DISC = 0.1;
    double GOLD_DISC = 0.075;
    double SILVER_DISC = 0.050;
    double getMembershipDiscount();
}
