package modul4.Tugas4;

public interface AlatElektronik {
    float MAX_DISCOUNT = 0.2f;
    float getDiscountedPrice(float price, float discount);
    void tampilkanAlatElektronik();

}
