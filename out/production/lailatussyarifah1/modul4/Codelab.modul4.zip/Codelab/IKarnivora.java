package modul4.Codelab;

public interface IKarnivora {
    void tampilkanMakanan();
}
