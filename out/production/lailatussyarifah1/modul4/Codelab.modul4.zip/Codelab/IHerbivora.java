package modul4.Codelab;

public interface IHerbivora {
    void tampilkanMakanan();
}
