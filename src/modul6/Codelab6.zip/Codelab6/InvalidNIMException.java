package modul6;

public class InvalidNIMException extends Exception{
    public InvalidNIMException(String message) {
        super(message);
    }
}
