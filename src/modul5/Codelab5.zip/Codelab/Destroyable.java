package modul5.Codelab;

public interface Destroyable {
    void destroyed();
}
