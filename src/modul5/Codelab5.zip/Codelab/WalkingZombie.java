package modul5.Codelab;

public class WalkingZombie extends Zombie {
    public WalkingZombie(int health){
        super(health);
    }
}
