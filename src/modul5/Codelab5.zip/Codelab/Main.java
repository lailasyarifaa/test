package modul5.Codelab;

public class Main {
    public static void main(String[] args) {
        Armor armor = new Armor(100);
        ArmoredZombie zombie = new ArmoredZombie(100,armor);

        System.out.println("====== Zombi Sebelum Diserang ======");
        zombie.getZombieInfo();

        Plant plant = new Plant();

        System.out.println("====== Plant manyerang ArmoredZombie ======");
        for (int i = 0; i < 5; i++){
            plant.attack(zombie);
            zombie.getZombieInfo();
        }
        plant.attack(zombie);
    }

}
