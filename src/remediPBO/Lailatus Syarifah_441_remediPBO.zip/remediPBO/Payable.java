package remediPBO;

public interface Payable {
    int getPaymentAmount();
    int getBasePrice();
    String getBillInfo();

}
